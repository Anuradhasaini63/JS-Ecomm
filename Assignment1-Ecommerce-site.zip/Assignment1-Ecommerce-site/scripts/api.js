export const apiURL = 'https://fakestoreapi.com/products';

export async function fetchedProducts() {
  try {
    
    const cachedProducts = localStorage.getItem('products');
    
    if (cachedProducts) {
      
      return JSON.parse(cachedProducts);
    } else {
      
      const products = await (await fetch(apiURL)).json();
      
      localStorage.setItem('products', JSON.stringify(products));

      return products;
    }
  } catch (error) {
    console.error('Error Occured:', error);
    return [];
  }
}
