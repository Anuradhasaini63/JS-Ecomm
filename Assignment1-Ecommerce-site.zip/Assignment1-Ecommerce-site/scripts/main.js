import { fetchedProducts } from './api.js';
import { displayProductsList } from './ui.js';
import { observeImg } from './lazyload.js';
import { handleSortChange, handleCategoryFilter } from './filter.js';
import { prod_Pagination, pagination_Controls } from './pagination.js';

let products = [];
let real_Products = []; 
let current_Page = 1;
const itemsPerPage = 8;

document.addEventListener('DOMContentLoaded', async () => {
 
  products = await fetchedProducts();
  real_Products = [...products];  


  displayPage(current_Page);

 
  const images = document.querySelectorAll('img[data-src]');
  images.forEach(image => observeImg(image)); 

  
  document.getElementById('sort-options').addEventListener('change', (e) => {
    handleSortChange(products, e, (sortedProducts) => {
      products = sortedProducts;  
      displayPage(current_Page);   
    });
  });

  
  const categoryCheckboxes = document.querySelectorAll('.category-checkbox');
  categoryCheckboxes.forEach(checkbox => {
    checkbox.addEventListener('change', () => {
      handleCategoryFilter(real_Products, (filteredProducts) => { 
        products = filteredProducts;  
        displayPage(current_Page);  
      });
    });
  });
});


function displayPage(page) {
  
  const paginatedProducts = prod_Pagination(products, page, itemsPerPage);

  
  displayProductsList(paginatedProducts);

  
  const images = document.querySelectorAll('img[data-src]');
  images.forEach(image => observeImg(image));

  
  pagination_Controls(products.length, page, itemsPerPage, (newPage) => {
    current_Page = newPage;  
    displayPage(newPage);   
  });
}
