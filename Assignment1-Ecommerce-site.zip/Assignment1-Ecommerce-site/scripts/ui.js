export function displayProductsList(products) {
  const product_List = document.getElementById('product_list');
  product_List.innerHTML = '';

  products.forEach(product => {
    const product_Div = document.createElement('div');
    product_Div.classList.add('product', 'shadow-lg', 'p-2', 'border', 'rounded', 'w-[370px]', 'h-[480px]', 'relative', 'm-5', 'transition', 'delay-150', 'duration-300', 'ease-in-out', 'hover:-translate-y-1', 'hover:scale-110');

    const img_Element = document.createElement('img');
    img_Element.dataset.src = product.image;
    img_Element.alt = product.title;
    img_Element.classList.add('w-[200px]', 'h-[200px]', 'object-contain', 'mx-auto');

    product_Div.innerHTML = `
    <h2 class="font-semibold line-clamp-2 mt-3 text-blue-800">${product.title}</h2>
    <p class="line-clamp-3 mt-2">${product.description}</p>
    <div class='text-black font-semibold'>Rs. ${product.price}</div>
    <div class="font-semibold">Rating: <span class="text-yellow-600">${product.rating.rate}</span></div>
    <button class="bg-blue-800 text-white px-4 py-2 mt-4 rounded hover:bg-blue-700 absolute bottom-5">Blue Button</button>
  `;

    product_Div.prepend(img_Element);

    product_List.appendChild(product_Div);
  });
}
