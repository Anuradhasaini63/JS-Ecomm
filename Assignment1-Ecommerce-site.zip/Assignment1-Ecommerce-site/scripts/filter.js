// Sorting starts
export function sorting_By_Price(products, order) {
  return products.sort((x, y) => {
    if (order === 'asc-order') {
      return x.price - y.price;
    } else {
      return y.price - x.price;
    }
  });
}

//  by name
export function sorting_By_Name(products, order) {
  return products.sort((x, y) => {
    if (order === 'asc-order') {
      return x.title.localeCompare(y.title);
    } else {
      return y.title.localeCompare(x.title);
    }
  });
}

//  by rating
export function sorting_By_Rating(products, order) {
  return products.sort((x, y) => {
    if (order === 'asc-order') {
      return x.rating.rate - y.rating.rate;
    } else {
      return y.rating.rate - x.rating.rate;
    }
  });
}





// Filter starts 

export function filter_ByCategory(products, selectedCategories) {
  return products.filter(product => {
    return selectedCategories.includes(product.category);
  });
}

export function handleSortChange(products, event, displayProductsList) {
  const sortValue = event.target.value;
  let sortedProducts = [...products];

  if (sortValue === 'price-asc') {

    sortedProducts = sorting_By_Price(sortedProducts, "asc-order");
  } else if (sortValue === "price-desc") {

    sortedProducts = sorting_By_Price(sortedProducts, "desc");
  } else if (sortValue === "name-asc") {

    sortedProducts = sorting_By_Name(sortedProducts, "asc-order");
  } else if (sortValue === "name-desc") {

    sortedProducts = sorting_By_Name(sortedProducts, "desc");
  } else if (sortValue === "rating-asc") {

    sortedProducts = sorting_By_Rating(sortedProducts, "asc-order");
  } else if (sortValue === "rating-desc") {

    sortedProducts = sorting_By_Rating(sortedProducts, "desc");
  }

  displayProductsList(sortedProducts);

  const images = document.querySelectorAll('img[data-src]');
  images.forEach(image => observeImg(image));
}

export function handleCategoryFilter(real_Products, displayProductsList) {
  const selectedCategories = [];
  const checkboxes = document.querySelectorAll('.category-checkbox:checked');
  checkboxes.forEach(checkbox => {

    selectedCategories.push(checkbox.value);
  });

  if (selectedCategories.length === 0) {
    displayProductsList(real_Products);
  } else {
    const filteredProducts = filter_ByCategory(real_Products, selectedCategories);
    displayProductsList(filteredProducts);
  }

  const images = document.querySelectorAll('img[data-src]');
  images.forEach(image => observeImg(image));
}
