
export function prod_Pagination(products, current_Page = 1, itemsPerPage = 6) {
  
  const startIndex = (current_Page - 1) * itemsPerPage;
  const endIndex = current_Page * itemsPerPage;
  
  return products.slice(startIndex, endIndex);
}

export function pagination_Controls(totalItems, current_Page, itemsPerPage, onPageChange) {
  const totalPages = Math.ceil(totalItems / itemsPerPage);
  
  const pagination_Wrapper = document.getElementById('pagination-controls');
  pagination_Wrapper.innerHTML = ''; 
  
  
  const prevBtn = document.createElement('button');
  prevBtn.textContent = 'Prev';
  prevBtn.disabled = current_Page === 1;
  prevBtn.addEventListener('click', () => onPageChange(current_Page - 1));
  pagination_Wrapper.appendChild(prevBtn);

  
  for (let i = 1; i <= totalPages; i++) {
    const pagebtn = document.createElement('button');
    pagebtn.textContent = i;
    pagebtn.classList.add('px-4', 'py-2', 'mx-1');
    pagebtn.classList.toggle('bg-blue-600', i === current_Page); 
    pagebtn.addEventListener('click', () => onPageChange(i));
    pagination_Wrapper.appendChild(pagebtn);
  }

  
  const nextBtn = document.createElement('button');
  nextBtn.textContent = 'Next';
  nextBtn.disabled = current_Page === totalPages;
  nextBtn.addEventListener('click', () => onPageChange(current_Page + 1));
  pagination_Wrapper.appendChild(nextBtn);
}
