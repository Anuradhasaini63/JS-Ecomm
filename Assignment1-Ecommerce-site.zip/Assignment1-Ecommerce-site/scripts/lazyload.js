
export function observeImg(image) {
  
  const observer = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {

      if (entry.isIntersecting) {
        
        const img = entry.target;
        img.src = img.dataset.src; 
        observer.unobserve(img); 
      }
    });
  }, { threshold: 0.1 });

  observer.observe(image); 
}  